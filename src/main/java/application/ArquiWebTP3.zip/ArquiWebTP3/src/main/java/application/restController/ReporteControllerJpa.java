//package application.restController;
//
//import application.entities.Estudiante;
//import application.repository.CarreraRepository;
//import application.repository.EstudianteCarreraRepository;
//import application.repository.EstudianteRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.Optional;
//
//@RestController
//@RequestMapping("reporte")
//public class ReporteControllerJpa {
//
//
//
//}
