//package application.repository;
//
//import application.entities.Reporte;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Service;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@Service
//public interface ReporteRepository extends JpaRepository<Reporte, Long> {
//
//}
