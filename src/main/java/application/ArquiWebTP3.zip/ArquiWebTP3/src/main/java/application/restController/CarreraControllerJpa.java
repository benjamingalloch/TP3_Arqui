package application.restController;

import application.entities.Carrera;
import application.entities.EstudianteCarrera;
import application.repository.CarreraRepository;
import application.repository.EstudianteCarreraRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Optional;

@RestController
@RequestMapping("carreras")
public class CarreraControllerJpa {

    @Qualifier("carreraRepository")
    @Autowired

    private final CarreraRepository repository;
    private final EstudianteCarreraRepository ecRepository;

    public CarreraControllerJpa(@Qualifier("carreraRepository") CarreraRepository repository, @Qualifier("estudianteCarreraRepository") EstudianteCarreraRepository ecRepository){
        this.repository = repository;
        this.ecRepository = ecRepository;
    }

    @GetMapping("")
    public Iterable<Carrera> getCarreras(){
        return repository.findAll();
    }

    @PostMapping("")
    public Carrera newCarrera (@RequestBody Carrera c){
        return repository.save(c);
    }

    @GetMapping("/{id}")
    Optional<Carrera> one(@PathVariable Long id){
        return repository.findById(id);
    }

    @GetMapping("/nombre/{nombre}")
    public Carrera getCarrerasByNombre(@PathVariable String nombre) {
        return repository.findByNombre(nombre);
    }

    @GetMapping("/cantInscriptos/{carrera}-{anio}")
    public Long getCantInscriptos(@PathVariable String carrera, @PathVariable int anio) {
        return repository.findCantInscriptos(carrera, anio);
    }

    @GetMapping("/cantEgregsados/{carrera}-{anio}")
    public Long getCantEgresados(@PathVariable String carrera, @PathVariable int anio) {
        return repository.findCantEgresados(carrera, anio);
    }

    @GetMapping("/aniosActivos/{id}")
    public Iterable<Integer> getAniosActivos(@PathVariable int id) {
        return repository.findAniosActivos(id);
    }

    @GetMapping("/conInscriptos")
    public Iterable<Carrera> getCarrerasConInscriptos() {
        return repository.findAllConInscriptos();
    }

    @PutMapping("/matricular")
    public EstudianteCarrera matricular(@RequestBody EstudianteCarrera ec) {
        return ecRepository.save(ec);
    }

}
