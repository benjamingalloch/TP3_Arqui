package application.restController;

import application.entities.Estudiante;
import application.repository.EstudianteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("estudiantes")
public class EstudianteControllerJpa {

    @Qualifier("estudianteRepository")
    @Autowired

    private final EstudianteRepository repository;

    public EstudianteControllerJpa(@Qualifier("estudianteRepository") EstudianteRepository repository){
        this.repository = repository;
    }

    @GetMapping("")
    public Iterable<Estudiante> getEstudiantes(){
        return repository.findAll();
    }

    @PostMapping("")
    public Estudiante newEstudiante (@RequestBody Estudiante e){
        return repository.save(e);
    }

    @GetMapping("/{id}")
    Optional<Estudiante> one(@PathVariable Long id){
        return repository.findById(id);
    }

    @GetMapping("/byLU/{numero}")
    public Iterable<Estudiante> getEstudiantesByNumeroDeLibreta(@PathVariable long numero){
        return repository.findByNumeroDeLibreta(numero);
    }

    @GetMapping("/byDNI/{dni}")
    public Estudiante getEstudianteByDNI(@PathVariable long dni){
        return repository.findByDNI(dni);
    }

    @GetMapping("/byGenero/{genero}")
    public Iterable<Estudiante> getEstudianteByGenero(@PathVariable String genero){
        return repository.findByGenero(genero);
    }

    @GetMapping("/byCarreraAndCiudad/{carrera}-{ciudad}")
    public Iterable<Estudiante> getEstudiantesByCarreraAndCiudad(@PathVariable String carrera, @PathVariable String ciudad){
        return repository.findAllByCarreraAndCiudad(carrera, ciudad);
    }
}
