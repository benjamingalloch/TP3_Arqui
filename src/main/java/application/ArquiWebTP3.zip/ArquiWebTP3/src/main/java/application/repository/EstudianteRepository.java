package application.repository;

import application.entities.Carrera;
import application.entities.Estudiante;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EstudianteRepository extends JpaRepository<Estudiante, Long> {

    @Query("SELECT es FROM Estudiante es WHERE es.numeroDeLibreta = :numero")
    public List<Estudiante> findByNumeroDeLibreta(@Param("numero")long numero);

    @Query("SELECT es FROM Estudiante es WHERE es.dni = :dni")
    public Estudiante findByDNI(@Param("dni") long dni);

    @Query("SELECT es FROM Estudiante es WHERE es.genero LIKE :genero")
    public List<Estudiante> findByGenero(@Param("genero") String genero);

    @Query("SELECT est FROM Estudiante est  " +
            "JOIN est.estudianteCarrera ec " +
            "WHERE ec.carrera.nombre  = :carrera " +
            "AND est.ciudadDeResidencia LIKE :ciudad ")
    public List<Estudiante> findAllByCarreraAndCiudad(@Param("carrera") String carrera, @Param("ciudad") String ciudad);

}
